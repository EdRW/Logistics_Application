package truck.utils;

public class CannotLoadException extends Exception
{
    public CannotLoadException(String msg)
    {
        super(msg);
    }
}
