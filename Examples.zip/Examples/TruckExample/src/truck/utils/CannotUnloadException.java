package truck.utils;

public class CannotUnloadException extends Exception
{
    public CannotUnloadException(String msg)
    {
        super(msg);
    }
}
