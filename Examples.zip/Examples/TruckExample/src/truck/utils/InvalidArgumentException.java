package truck.utils;

public class InvalidArgumentException extends Exception
{
    public InvalidArgumentException(String msg)
    {
        super(msg);
    }
}
